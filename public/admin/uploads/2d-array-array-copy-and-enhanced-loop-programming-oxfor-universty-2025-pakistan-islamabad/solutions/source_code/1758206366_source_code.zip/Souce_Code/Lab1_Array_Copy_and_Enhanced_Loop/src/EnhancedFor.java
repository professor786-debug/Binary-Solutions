public class EnhancedFor {
    public static void main(String[] args) {
        int[] numbers = {3, 6, 9};     
        for (int val : numbers) 
        {
            System.out.println(val);
        }
    }
}
