using System;

class Program
{
    static void Main(string[] args)
    {
        // Create two students
        Student maleStudent = new Student("1001");
        Student femaleStudent = new Student("1002", "Sarah");

        // Set name for male student
        maleStudent.setName("Alex");

        // Set GPA
        maleStudent.setGPA(3.2);
        femaleStudent.setGPA(3.8);

        // Compare GPA with average
        double average = 2.7;

        if (maleStudent.isHigher(average))
            Console.WriteLine("Yes, " + maleStudent.getName() + "'s GPA is higher than " + average);
        else
            Console.WriteLine("No, " + maleStudent.getName() + "'s GPA is not higher than " + average);

        if (femaleStudent.isHigher(average))
            Console.WriteLine("Yes, " + femaleStudent.getName() + "'s GPA is higher than " + average);
        else
            Console.WriteLine("No, " + femaleStudent.getName() + "'s GPA is not higher than " + average);
            
        
        // line spacing
        Console.WriteLine();


        // Show GPA of female student
        Console.WriteLine(femaleStudent.getName() + "'s GPA: " + femaleStudent.getGPA());

        // Show name of male student
        Console.WriteLine("Male student's name: " + maleStudent.getName());

        // Show info of both students
        Console.WriteLine("\nMale Student Info:");
        Console.WriteLine(maleStudent.ToString());

        Console.WriteLine("\nFemale Student Info:");
        Console.WriteLine(femaleStudent.ToString());
    }
}
