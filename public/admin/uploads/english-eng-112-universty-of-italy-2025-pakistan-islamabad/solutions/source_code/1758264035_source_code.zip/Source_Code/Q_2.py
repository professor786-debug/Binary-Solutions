import pandas as df

# Reading Excel file
StudentsScores = df.read_excel("students_scores.xlsx")

# Display first 5 rows
print("\nFirst 5 rows of StudentsScores:\n")
print(StudentsScores.head())

#  Summary using describe function
print("\nSummary using describe():\n")
print(StudentsScores.describe())

# Shape of the DataFrame
rows, columns = StudentsScores.shape
print(f"\nThe DataFrame has {rows} rows and {columns} columns.\n")

# Count Section A students
section_a_count = StudentsScores[StudentsScores["Section"] == "A"].shape[0]
print("Number of students in Section A:", section_a_count)

# Student with lowest math score
lowest_math = StudentsScores[StudentsScores["Math"] == StudentsScores["Math"].min()]
print("\nStudent(s) with the lowest Math score:\n")
print(lowest_math)

# Student with highest english score
highest_english = StudentsScores[StudentsScores["English"] == StudentsScores["English"].max()]
print("\nStudent with the highest English score:\n")
print(highest_english)

# Student with lowest total score
StudentsScores["Total_Score"] = (StudentsScores["Math"] + StudentsScores["Physics"] + StudentsScores["Chemistry"] + StudentsScores["English"])
min_score = StudentsScores["Total_Score"].min()
lowest_total = StudentsScores[StudentsScores["Total_Score"] == min_score]
print("\nStudent(s) with the lowest total score:\n")
print(lowest_total)
