--------------------------------------------------------------
************* Method 1: Using Visual Studio Code *************
--------------------------------------------------------------
1. Install the extension in VS Code: C# Dev Kit 

2. Create a new folder and save these files in it:

	# Student.cs (contains the Student class code)

	# Program.cs (contains the Main method)

3. Open the folder in VS Code:

4. Click "File" > "Open Folder"

5. Select your project folder

6. Run the program by either:

7. Right-clicking in the code editor and selecting "Run Code"

8. View the output in the terminal window at the bottom

---------------------------------------------------------------
************* Method 2: Using Online Compiler *************
---------------------------------------------------------------
1. Go to an online C# compiler like:

	# https://onecompiler.com/csharp

2. Clear any existing code in the editor

3. Create two separate tabs/files:

4. Name one "Student.cs" and paste the Student class code

5. Name the other "Program.cs" and paste the Main method code

6. Make sure both files are saved in the compiler

7. Click the "Run" or "Execute" button

8. View the output in the results panel