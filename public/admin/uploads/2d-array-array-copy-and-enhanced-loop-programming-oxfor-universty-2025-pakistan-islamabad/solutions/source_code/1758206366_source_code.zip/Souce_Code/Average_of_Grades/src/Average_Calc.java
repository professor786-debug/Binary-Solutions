public class Average_Calc {
   // claculating the class average
    public static double calculateClassAverage(double[][] grades) {
        double total = 0;  // initialize total variable
        for (int i = 0; i < grades.length; i++) {      
            for (int j = 0; j < grades[i].length; j++) {
                total += grades[i][j];
            }
        }
        return total / (grades.length * 2);  //return  total average
    }
// calculating the average of math and science subject
    public static double[] calculateSubjectAverages(double[][] grades) {
        double mathTotal = 0;  // initialize math total variable
        double scienceTotal = 0;  // initialize science total variable
         
        for (int i = 0; i < grades.length; i++) { // loop to iterate through each subject grades
            mathTotal += grades[i][0];
            scienceTotal += grades[i][1];
        }
        return new double[]{mathTotal / grades.length, scienceTotal / grades.length};   // return an array with math and science averages
    }

// main method 
     public static void main(String[] args) {
        double[][] grades = {  // 2D array of grades for math and science subjects
                {80.5, 25.5}, 
                {100, 92.5}, 
                {75.0, 65.5}, 
                {82.3, 79.6},
                {35.9, 22.7}, 
                {73.6, 66.2}, 
                {88.9, 98.7}, 
                {46.2, 62.3},
                {100, 100}, 
                {97.8, 99.5}
               
        };

        double classAvg = calculateClassAverage(grades);   //calling the method to calculate class average
        double[] subjectAverages = calculateSubjectAverages(grades);   // calling the method to calculate subject averages
        // displaying the results
        System.out.printf("Class Average: %.2f\n", classAvg);
        System.out.printf("Math Average: %.2f\n", subjectAverages[0]);
        System.out.printf("Science Average: %.2f\n", subjectAverages[1]);
    }
}
