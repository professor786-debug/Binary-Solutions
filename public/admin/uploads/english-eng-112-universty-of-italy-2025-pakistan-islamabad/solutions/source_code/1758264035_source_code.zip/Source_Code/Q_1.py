import pandas as df

# dictionary
Countries = {
    "Country": ["Germany", "China", "United States", "India", "Brazil", 
            "Spain", "Australia", "Canada", "France", "United Arab Emirates"],
    "Population_millions": [83, 1441, 331, 1380, 213, 47, 26, 38, 67, 10],
    "Renewable_Capacity_GW": [120, 900, 280, 150, 140, 55, 60, 65, 70, 15],
    "Solar_Projects_Completed": [350, 1200, 850, 600, 420, 310, 540, 200, 330, 180]
}

# DataFrame
DF_Countries = df.DataFrame(Countries)

# Print the DataFrame
print("Complete DataFrame:" )
print(DF_Countries)
print("\n")

# Display first 5 rows
print("First 5 rows:")
print(DF_Countries.head())
print("\n")

# adding new columns 
DF_Countries["Capacity_per_Capita_MW"] = (DF_Countries["Renewable_Capacity_GW"] * 1000) / DF_Countries["Population_millions"]
DF_Countries["Projects_per_Million"] = DF_Countries["Solar_Projects_Completed"] / DF_Countries["Population_millions"]

# Print header of augmented DataFrame
print("Header of augmented DataFrame:")
print(DF_Countries)
print("\n")


# Countries with Capacity_per_Capita_MW > 1,500 and Projects_per_Million > 10
filtered_countries = DF_Countries[(DF_Countries["Capacity_per_Capita_MW"] > 1500) & 
                                 (DF_Countries["Projects_per_Million"] > 10)]
print("Countries with Capacity_per_Capita_MW > 1,500 and Projects_per_Million > 10:")
print(filtered_countries)
print("\n")

# Average Solar_Projects_Completed for countries with Renewable_Capacity_GW > 100 GW
average_projects = DF_Countries[DF_Countries["Renewable_Capacity_GW"] > 100]["Solar_Projects_Completed"].mean()
print(f"Average Solar Projects Completed for countries with Renewable Capacity > 100 GW: {average_projects}")