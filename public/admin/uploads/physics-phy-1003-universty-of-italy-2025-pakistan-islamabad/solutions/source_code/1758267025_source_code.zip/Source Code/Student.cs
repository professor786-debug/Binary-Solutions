using System;

public class Student
{
    // Fields
    private string id;
    private string name;
    private double gpa;

    // Constructors
    public Student(string id)
    {
        this.id = id;
    }

    public Student(string id, string name)
    {
        this.id = id;
        this.name = name;
    }

    // Set methods
    public void setName(string name)
    {
        this.name = name;
    }

    public void setGPA(double value)
    {
        this.gpa = value;
    }

    // Get methods
    public double getGPA()
    {
        return gpa;
    }

    public string getName()
    {
        return name;
    }

    // Comparison method
    public bool isHigher(double av)
    {
        return gpa > av;
    }

    // Override ToString method
    public override string ToString()
    {
        return $"Student ID: {id}\nName: {name}\nGPA: {gpa:F2}";
    }
}